// VOID screensaver - cleaned Direct2D / DirectWrite edition
// Hardware-accelerated rendering where supported. Image glow is precomputed once.
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shellapi.h>
#include <shlobj.h>
#include <d2d1.h>
#include <dwrite.h>
#include <wincodec.h>
#include <dxgi.h>
#include <wrl/client.h>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <string>
#include <sstream>
#include <iomanip>
#include <iterator>
#include <vector>

#pragma comment(lib, "User32.lib")
#pragma comment(lib, "Shell32.lib")
#pragma comment(lib, "d2d1.lib")
#pragma comment(lib, "dwrite.lib")
#pragma comment(lib, "windowscodecs.lib")
#pragma comment(lib, "dxgi.lib")
#pragma comment(lib, "Advapi32.lib")
#pragma comment(lib, "Ole32.lib")

using Microsoft::WRL::ComPtr;
static ComPtr<ID2D1Factory> g_d2d;
static ComPtr<IDWriteFactory> g_dwrite;
static ComPtr<IWICImagingFactory> g_wic;
static ComPtr<IDWriteTextFormat> g_clockFormat, g_smallFormat;
static ComPtr<ID2D1Bitmap> g_mikuBitmap, g_glowBitmap;
static HWND g_primaryWindow = nullptr;
static bool g_preview = false, g_haveInitialMouse = false;
static ULONGLONG g_started = 0;
static POINT g_initialMouse{};
static int g_cursorHideCalls = 0;
static constexpr UINT_PTR TIMER_ID = 1;
static constexpr ULONGLONG TEXT_DELAY_MS = 2000, TEXT_FADE_MS = 3000;
static constexpr ULONGLONG MIKU_DELAY_MS = 30000, MIKU_FADE_MS = 4500;
static constexpr UINT ANIM_TIMER_MS = 67, IDLE_TIMER_MS = 1000;
static ULONGLONG g_lastIdle = 0, g_lastKernel = 0, g_lastUser = 0;
static double g_cpuPercent = 0.0;
static std::wstring g_gpuTextCache = L"GPU       | UNAVAILABLE";
static ULONGLONG g_gpuCacheAt = 0;

struct MonitorInfo { RECT rect; bool primary; };
static std::vector<MonitorInfo> g_monitors;
struct WindowRender {
    ComPtr<ID2D1HwndRenderTarget> target;
    ComPtr<ID2D1SolidColorBrush> white, date, heading, cpu, cpuModel, memory, gpu, uptime, particle, particleGlow;
};
static WindowRender g_mainRender, g_secondaryRender;
struct Particle { float x, y, speed, phase, size; bool onCharacter; };
static std::vector<Particle> g_particles;
static std::wstring g_configPath, g_imagePath;
static bool g_postBlur = true;
static D2D1_COLOR_F g_particleColor = D2D1::ColorF(0x00E5CC);
static float g_particleSizeScale = 1.0f;
static int g_particleAmount = 50;

static std::wstring GetExeDir();
static std::wstring GetUserVoidDir() {
    // Keep user-editable settings and the default image in Documents\VOID.
    PWSTR documents = nullptr;
    if (SUCCEEDED(SHGetKnownFolderPath(FOLDERID_Documents, KF_FLAG_CREATE, nullptr, &documents)) && documents) {
        std::wstring base(documents);
        CoTaskMemFree(documents);
        return base + L"\\VOID";
    }
    // Fallback for unusual Windows profiles where the known folder cannot be resolved.
    wchar_t profile[MAX_PATH]{};
    DWORD n = GetEnvironmentVariableW(L"USERPROFILE", profile, MAX_PATH);
    std::wstring base = (n && n < MAX_PATH) ? std::wstring(profile, n) + L"\\Documents" : GetExeDir();
    return base + L"\\VOID";
}
static bool EnsureDirectory(const std::wstring& path) {
    if (CreateDirectoryW(path.c_str(), nullptr)) return true;
    return GetLastError() == ERROR_ALREADY_EXISTS;
}
static D2D1_COLOR_F ParseHexColor(const std::wstring& value, D2D1_COLOR_F fallback) {
    if (value.size() != 7 || value[0] != L'#') return fallback;
    wchar_t* end = nullptr;
    unsigned long rgb = wcstoul(value.c_str() + 1, &end, 16);
    if (!end || *end != L'\0' || end != value.c_str() + 7) return fallback;
    return D2D1::ColorF((float)((rgb >> 16) & 255) / 255.0f,
                        (float)((rgb >> 8) & 255) / 255.0f,
                        (float)(rgb & 255) / 255.0f, 1.0f);
}
static std::wstring GetConfiguredPath(const std::wstring& value) {
    if (value.empty()) return L"";
    if ((value.size() > 1 && value[1] == L':') || value.rfind(L"\\\\", 0) == 0) return value;
    // Relative image paths are resolved beside Void.ini (Documents\VOID), not beside Void.scr.
    return GetUserVoidDir() + L"\\" + value;
}
static void LoadSettings() {
    std::wstring userDir = GetUserVoidDir();
    EnsureDirectory(userDir);
    g_configPath = userDir + L"\\Void.ini";
    if (GetFileAttributesW(g_configPath.c_str()) == INVALID_FILE_ATTRIBUTES) {
        WritePrivateProfileStringW(L"Appearance", L"Image", L"background.png", g_configPath.c_str());
        WritePrivateProfileStringW(L"Appearance", L"PostBlur", L"true", g_configPath.c_str());
        WritePrivateProfileStringW(L"Appearance", L"ParticleColor", L"#00E5CC", g_configPath.c_str());
        WritePrivateProfileStringW(L"Appearance", L"ParticleSize", L"1.0", g_configPath.c_str());
        WritePrivateProfileStringW(L"Appearance", L"ParticleAmount", L"50", g_configPath.c_str());
    }
    wchar_t value[MAX_PATH * 4]{};
    GetPrivateProfileStringW(L"Appearance", L"Image", L"background.png", value, (DWORD)std::size(value), g_configPath.c_str());
    g_imagePath = GetConfiguredPath(value);
    GetPrivateProfileStringW(L"Appearance", L"PostBlur", L"true", value, (DWORD)std::size(value), g_configPath.c_str());
    g_postBlur = (_wcsicmp(value, L"true") == 0 || wcscmp(value, L"1") == 0 || _wcsicmp(value, L"yes") == 0 || _wcsicmp(value, L"on") == 0);
    GetPrivateProfileStringW(L"Appearance", L"ParticleColor", L"#00E5CC", value, (DWORD)std::size(value), g_configPath.c_str());
    g_particleColor = ParseHexColor(value, D2D1::ColorF(0x00E5CC));
    GetPrivateProfileStringW(L"Appearance", L"ParticleSize", L"1.0", value, (DWORD)std::size(value), g_configPath.c_str());
    wchar_t* sizeEnd = nullptr;
    double configuredSize = wcstod(value, &sizeEnd);
    if (sizeEnd != value && *sizeEnd == L'\0' && std::isfinite(configuredSize))
        g_particleSizeScale = (float)(std::max)(0.1, (std::min)(5.0, configuredSize));
    g_particleAmount = GetPrivateProfileIntW(L"Appearance", L"ParticleAmount", 50, g_configPath.c_str());
    g_particleAmount = (std::max)(0, (std::min)(200, g_particleAmount));
}

static std::wstring Two(int n) { std::wostringstream s; s << std::setw(2) << std::setfill(L'0') << n; return s.str(); }
static std::wstring GetClockText() {
    SYSTEMTIME t{}; GetLocalTime(&t); int h = t.wHour % 12; if (!h) h = 12;
    return std::to_wstring(h) + L":" + Two(t.wMinute) + L":" + Two(t.wSecond) + (t.wHour >= 12 ? L" PM" : L" AM");
}
static std::wstring GetDateText() {
    SYSTEMTIME t{}; GetLocalTime(&t);
    static const wchar_t* days[] = { L"SUNDAY",L"MONDAY",L"TUESDAY",L"WEDNESDAY",L"THURSDAY",L"FRIDAY",L"SATURDAY" };
    static const wchar_t* months[] = { L"JANUARY",L"FEBRUARY",L"MARCH",L"APRIL",L"MAY",L"JUNE",L"JULY",L"AUGUST",L"SEPTEMBER",L"OCTOBER",L"NOVEMBER",L"DECEMBER" };
    return std::wstring(days[t.wDayOfWeek]) + L"  |  " + months[t.wMonth - 1] + L" " + std::to_wstring(t.wDay) + L"  |  " + std::to_wstring(t.wYear);
}
static void UpdateCpu() {
    FILETIME idle{}, kernel{}, user{}; if (!GetSystemTimes(&idle, &kernel, &user)) return;
    ULARGE_INTEGER i{}, k{}, u{};
    i.LowPart = idle.dwLowDateTime; i.HighPart = idle.dwHighDateTime;
    k.LowPart = kernel.dwLowDateTime; k.HighPart = kernel.dwHighDateTime;
    u.LowPart = user.dwLowDateTime; u.HighPart = user.dwHighDateTime;
    if (g_lastKernel || g_lastUser) {
        ULONGLONG di = i.QuadPart - g_lastIdle;
        ULONGLONG total = (k.QuadPart - g_lastKernel) + (u.QuadPart - g_lastUser);
        if (total) g_cpuPercent = 100.0 * (double)(total > di ? total - di : 0) / (double)total;
        g_cpuPercent = (std::max)(0.0, (std::min)(100.0, g_cpuPercent));
    }
    g_lastIdle = i.QuadPart; g_lastKernel = k.QuadPart; g_lastUser = u.QuadPart;
}
static std::wstring FixedInfoLine(const wchar_t* label, const std::wstring& value) {
    std::wostringstream s; s << std::left << std::setw(9) << label << L" | " << value; return s.str();
}
static std::wstring GetCpuName() {
    static std::wstring cached; if (!cached.empty()) return cached;
    HKEY key = nullptr; wchar_t name[256]{};
    if (RegOpenKeyExW(HKEY_LOCAL_MACHINE, L"HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", 0, KEY_QUERY_VALUE, &key) == ERROR_SUCCESS) {
        DWORD size = sizeof(name);
        if (RegQueryValueExW(key, L"ProcessorNameString", nullptr, nullptr, reinterpret_cast<BYTE*>(name), &size) != ERROR_SUCCESS) name[0] = L'\0';
        RegCloseKey(key);
    }
    cached = name[0] ? name : L"UNAVAILABLE"; return cached;
}
static std::wstring GetGpuText() {
    ULONGLONG now = GetTickCount64(); if (g_gpuCacheAt && now - g_gpuCacheAt < 30000) return g_gpuTextCache;
    g_gpuCacheAt = now; ComPtr<IDXGIFactory1> factory;
    if (FAILED(CreateDXGIFactory1(IID_PPV_ARGS(factory.GetAddressOf())))) { g_gpuTextCache = FixedInfoLine(L"GPU", L"UNAVAILABLE"); return g_gpuTextCache; }
    std::wstring result = L"UNAVAILABLE";
    for (UINT i = 0;; ++i) {
        ComPtr<IDXGIAdapter1> adapter;
        if (factory->EnumAdapters1(i, adapter.GetAddressOf()) == DXGI_ERROR_NOT_FOUND) break;
        DXGI_ADAPTER_DESC1 d{};
        if (SUCCEEDED(adapter->GetDesc1(&d)) && !(d.Flags & DXGI_ADAPTER_FLAG_SOFTWARE)) { result = d.Description; break; }
    }
    if (result.size() > 38) result = result.substr(0, 35) + L"...";
    g_gpuTextCache = FixedInfoLine(L"GPU", result); return g_gpuTextCache;
}
static std::wstring GetMemoryText() {
    MEMORYSTATUSEX m{}; m.dwLength = sizeof(m);
    if (!GlobalMemoryStatusEx(&m)) return FixedInfoLine(L"MEMORY", L"UNAVAILABLE");
    double used = (double)(m.ullTotalPhys - m.ullAvailPhys) / (1024.0 * 1024.0 * 1024.0);
    double total = (double)m.ullTotalPhys / (1024.0 * 1024.0 * 1024.0);
    std::wostringstream s; s << std::fixed << std::setprecision(1) << used << L" | " << total << L" GB";
    return FixedInfoLine(L"MEMORY", s.str());
}
static std::wstring GetUptimeText() {
    ULONGLONG sec = GetTickCount64() / 1000, days = sec / 86400; sec %= 86400;
    ULONGLONG hours = sec / 3600; sec %= 3600;
    std::wostringstream s; if (days) s << days << L"d "; s << hours << L"h " << sec / 60 << L"m";
    return FixedInfoLine(L"UPTIME", s.str());
}
static std::wstring GetExeDir() {
    wchar_t path[MAX_PATH]{}; DWORD n = GetModuleFileNameW(nullptr, path, MAX_PATH);
    if (!n || n >= MAX_PATH) return L".";
    std::wstring s(path, n); auto p = s.find_last_of(L"\\/"); if (p != std::wstring::npos) s.resize(p); return s;
}
static bool LoadImageFromFile(const std::wstring& path, ComPtr<ID2D1Bitmap>& out) {
    ComPtr<IWICBitmapDecoder> decoder;
    HRESULT hr = g_wic->CreateDecoderFromFilename(path.c_str(), nullptr, GENERIC_READ, WICDecodeMetadataCacheOnLoad, decoder.GetAddressOf());
    if (FAILED(hr)) return false;
    ComPtr<IWICBitmapFrameDecode> frame; if (FAILED(decoder->GetFrame(0, frame.GetAddressOf()))) return false;
    ComPtr<IWICFormatConverter> conv; if (FAILED(g_wic->CreateFormatConverter(conv.GetAddressOf()))) return false;
    if (FAILED(conv->Initialize(frame.Get(), GUID_WICPixelFormat32bppPBGRA, WICBitmapDitherTypeNone, nullptr, 0.0, WICBitmapPaletteTypeCustom))) return false;
    return SUCCEEDED(g_mainRender.target->CreateBitmapFromWicBitmap(conv.Get(), nullptr, out.GetAddressOf()));
}
static bool CreateFeatheredImage(const std::wstring& sourcePath, const std::wstring& outputPath) {
    // Write a separate PNG with transparent, feathered edges. Preserve the original image.
    ComPtr<IWICBitmapDecoder> decoder;
    if (FAILED(g_wic->CreateDecoderFromFilename(sourcePath.c_str(), nullptr, GENERIC_READ,
        WICDecodeMetadataCacheOnLoad, decoder.GetAddressOf()))) return false;
    ComPtr<IWICBitmapFrameDecode> frame;
    ComPtr<IWICFormatConverter> converter;
    if (FAILED(decoder->GetFrame(0, frame.GetAddressOf())) ||
        FAILED(g_wic->CreateFormatConverter(converter.GetAddressOf()))) return false;
    if (FAILED(converter->Initialize(frame.Get(), GUID_WICPixelFormat32bppPBGRA,
        WICBitmapDitherTypeNone, nullptr, 0.0, WICBitmapPaletteTypeCustom))) return false;
    UINT w = 0, h = 0;
    if (FAILED(converter->GetSize(&w, &h)) || !w || !h || (size_t)w * h > 12000000) return false;
    std::vector<BYTE> pixels((size_t)w * h * 4);
    if (FAILED(converter->CopyPixels(nullptr, w * 4, (UINT)pixels.size(), pixels.data()))) return false;

    // Smoothly fade the outer 7% of the shorter image dimension.
    const float feather = (std::max)(8.0f, (float)(std::min)(w, h) * 0.07f);
    for (UINT y = 0; y < h; ++y) for (UINT x = 0; x < w; ++x) {
        float d = (std::min)((std::min)((float)x, (float)(w - 1 - x)),
                             (std::min)((float)y, (float)(h - 1 - y)));
        float t = (std::max)(0.0f, (std::min)(1.0f, d / feather));
        t = t * t * (3.0f - 2.0f * t);
        size_t q = ((size_t)y * w + x) * 4;
        pixels[q] = (BYTE)(pixels[q] * t);
        pixels[q + 1] = (BYTE)(pixels[q + 1] * t);
        pixels[q + 2] = (BYTE)(pixels[q + 2] * t);
        pixels[q + 3] = (BYTE)(pixels[q + 3] * t);
    }

    for (size_t q = 0; q < pixels.size(); q += 4) {
        BYTE a = pixels[q + 3];
        if (a) {
            pixels[q]     = (BYTE)(std::min)(255, (int)pixels[q] * 255 / a);
            pixels[q + 1] = (BYTE)(std::min)(255, (int)pixels[q + 1] * 255 / a);
            pixels[q + 2] = (BYTE)(std::min)(255, (int)pixels[q + 2] * 255 / a);
        } else pixels[q] = pixels[q + 1] = pixels[q + 2] = 0;
    }

    ComPtr<IWICStream> stream; ComPtr<IWICBitmapEncoder> encoder;
    ComPtr<IWICBitmapFrameEncode> outFrame; ComPtr<IPropertyBag2> props;
    if (FAILED(g_wic->CreateStream(stream.GetAddressOf())) ||
        FAILED(stream->InitializeFromFilename(outputPath.c_str(), GENERIC_WRITE)) ||
        FAILED(g_wic->CreateEncoder(GUID_ContainerFormatPng, nullptr, encoder.GetAddressOf())) ||
        FAILED(encoder->Initialize(stream.Get(), WICBitmapEncoderNoCache)) ||
        FAILED(encoder->CreateNewFrame(outFrame.GetAddressOf(), props.GetAddressOf())) ||
        FAILED(outFrame->Initialize(props.Get())) || FAILED(outFrame->SetSize(w, h))) return false;
    WICPixelFormatGUID format = GUID_WICPixelFormat32bppBGRA;
    if (FAILED(outFrame->SetPixelFormat(&format)) || !IsEqualGUID(format, GUID_WICPixelFormat32bppBGRA)) return false;
    if (FAILED(outFrame->WritePixels(h, w * 4, (UINT)pixels.size(), pixels.data())) ||
        FAILED(outFrame->Commit()) || FAILED(encoder->Commit())) return false;
    return true;
}
static void BuildGlowMask(const std::wstring& imagePath) {
    // Read the image with WIC and make a soft cyan alpha mask once at startup.
    ComPtr<IWICBitmapDecoder> dec;
    if (FAILED(g_wic->CreateDecoderFromFilename(imagePath.c_str(), nullptr, GENERIC_READ, WICDecodeMetadataCacheOnLoad, dec.GetAddressOf()))) return;
    ComPtr<IWICBitmapFrameDecode> frame; ComPtr<IWICFormatConverter> conv;
    if (FAILED(dec->GetFrame(0, frame.GetAddressOf())) || FAILED(g_wic->CreateFormatConverter(conv.GetAddressOf()))) return;
    if (FAILED(conv->Initialize(frame.Get(), GUID_WICPixelFormat32bppPBGRA, WICBitmapDitherTypeNone, nullptr, 0, WICBitmapPaletteTypeCustom))) return;
    UINT w = 0, h = 0;
    if (FAILED(frame->GetSize(&w, &h))) return;
    if (!w || !h || (size_t)w * h > 12000000) return;
    std::vector<BYTE> src((size_t)w * h * 4);
    if (FAILED(conv->CopyPixels(nullptr, w * 4, (UINT)src.size(), src.data()))) return;
    const UINT downW = (w + 1) / 2, downH = (h + 1) / 2, pad = 32, pw = downW + pad * 2, ph = downH + pad * 2;
    std::vector<BYTE> alpha((size_t)pw * ph, 0);
    for (UINT y = 0; y < downH; ++y) for (UINT x = 0; x < downW; ++x) {
        int best = 0;
        for (UINT oy = 0; oy < 2; ++oy) for (UINT ox = 0; ox < 2; ++ox) {
            UINT sx = x * 2 + ox, sy = y * 2 + oy;
            if (sx < w && sy < h) {
                size_t q = ((size_t)sy * w + sx) * 4;
                int lum = src[q] + src[q + 1] + src[q + 2];
                if (src[q + 3] > 8 && lum > 35) best = (std::max)(best, (std::min)(150, (lum - 25) / 2));
            }
        }
        alpha[(size_t)(y + pad) * pw + x + pad] = (BYTE)best;
    }
    const int radius = 20; const float sigma = 7.0f; float kernel[radius * 2 + 1]{}; float sum = 0;
    for (int i = -radius; i <= radius; ++i) { float v = expf(-(float)(i * i) / (2 * sigma * sigma)); kernel[i + radius] = v; sum += v; }
    for (float& v : kernel) v /= sum;
    std::vector<float> temp((size_t)pw * ph, 0); std::vector<BYTE> blurred((size_t)pw * ph * 4, 0);
    for (UINT y = 0; y < ph; ++y) for (UINT x = 0; x < pw; ++x) {
        float a = 0; for (int k = -radius; k <= radius; ++k) { int xx = (int)x + k; if (xx >= 0 && xx < (int)pw) a += alpha[(size_t)y * pw + xx] * kernel[k + radius]; }
        temp[(size_t)y * pw + x] = a;
    }
    for (UINT y = 0; y < ph; ++y) for (UINT x = 0; x < pw; ++x) {
        float a = 0; for (int k = -radius; k <= radius; ++k) { int yy = (int)y + k; if (yy >= 0 && yy < (int)ph) a += temp[(size_t)yy * pw + x] * kernel[k + radius]; }
        BYTE A = (BYTE)(std::min)(150.0f, a * 1.35f); size_t q = ((size_t)y * pw + x) * 4;
        // Premultiplied cyan-blue glow (BGRA). Keep this soft layer behind the sharp image.
        blurred[q] = A; blurred[q + 1] = (BYTE)(165 * A / 255); blurred[q + 2] = (BYTE)(18 * A / 255); blurred[q + 3] = A;
    }
    ComPtr<IWICBitmap> bitmap;
    if (SUCCEEDED(g_wic->CreateBitmapFromMemory(pw, ph, GUID_WICPixelFormat32bppPBGRA, pw * 4, (UINT)blurred.size(), blurred.data(), bitmap.GetAddressOf())))
        g_mainRender.target->CreateBitmapFromWicBitmap(bitmap.Get(), nullptr, g_glowBitmap.GetAddressOf());
}
static void LoadMiku() {
    if (g_imagePath.empty() || GetFileAttributesW(g_imagePath.c_str()) == INVALID_FILE_ATTRIBUTES) return;
    std::wstring processed = GetUserVoidDir() + L"\\background_void.png";
    if (g_postBlur && CreateFeatheredImage(g_imagePath, processed)) {
        if (!LoadImageFromFile(processed, g_mikuBitmap)) LoadImageFromFile(g_imagePath, g_mikuBitmap);
    } else {
        LoadImageFromFile(g_imagePath, g_mikuBitmap);
    }
    if (!g_mikuBitmap) return;
    srand((unsigned int)GetTickCount64());
    // Keep roughly 72% of particles around the character and the rest drifting across the screen.
    const int characterCount = (int)(g_particleAmount * 0.72f + 0.5f);
    const int ambientCount = g_particleAmount - characterCount;
    for (int i = 0; i < characterCount; ++i) {
        float angle = (rand() % 628) / 100.0f, radius = .45f + (rand() % 70) / 100.0f;
        g_particles.push_back({ .5f + cosf(angle) * radius * .62f, .5f + sinf(angle) * radius * .58f,
            .006f + (rand() % 12) / 1000.f, (rand() % 628) / 100.f, .7f + (rand() % 18) / 10.f, false });
    }
    for (int i = 0; i < ambientCount; ++i) g_particles.push_back({ .12f + (rand() % 76) / 100.f, .08f + (rand() % 84) / 100.f,
        .002f + (rand() % 8) / 1000.f, (rand() % 628) / 100.f, .6f + (rand() % 12) / 10.f, true });
}
static HRESULT CreateRender(HWND hwnd, WindowRender& r) {
    RECT rc{}; GetClientRect(hwnd, &rc);
    D2D1_SIZE_U size = D2D1::SizeU((UINT32)(std::max)(1L, rc.right - rc.left), (UINT32)(std::max)(1L, rc.bottom - rc.top));
    HRESULT hr = g_d2d->CreateHwndRenderTarget(
        D2D1::RenderTargetProperties(D2D1_RENDER_TARGET_TYPE_DEFAULT,
            D2D1::PixelFormat(DXGI_FORMAT_UNKNOWN, D2D1_ALPHA_MODE_UNKNOWN), 0, 0,
            D2D1_RENDER_TARGET_USAGE_NONE, D2D1_FEATURE_LEVEL_DEFAULT),
        D2D1::HwndRenderTargetProperties(hwnd, size, D2D1_PRESENT_OPTIONS_NONE), r.target.GetAddressOf());
    if (FAILED(hr)) return hr;
    auto brush = [&](ComPtr<ID2D1SolidColorBrush>& b, D2D1_COLOR_F c) -> HRESULT { return r.target->CreateSolidColorBrush(c, b.GetAddressOf()); };
    if (FAILED(brush(r.white, D2D1::ColorF(1, 1, 1))) || FAILED(brush(r.date, D2D1::ColorF(.76f, .76f, .76f))) ||
        FAILED(brush(r.heading, D2D1::ColorF(1, 1, 1))) || FAILED(brush(r.cpu, D2D1::ColorF(.93f, .93f, .93f))) ||
        FAILED(brush(r.cpuModel, D2D1::ColorF(.85f, .85f, .85f))) || FAILED(brush(r.memory, D2D1::ColorF(.77f, .77f, .77f))) ||
        FAILED(brush(r.gpu, D2D1::ColorF(.69f, .69f, .69f))) || FAILED(brush(r.uptime, D2D1::ColorF(.61f, .61f, .61f))) ||
        FAILED(brush(r.particle, g_particleColor)) || FAILED(brush(r.particleGlow, D2D1::ColorF(g_particleColor.r, g_particleColor.g, g_particleColor.b, .12f)))) return E_FAIL;
    if (!g_clockFormat) {
        hr = g_dwrite->CreateTextFormat(L"Consolas", nullptr, DWRITE_FONT_WEIGHT_NORMAL, DWRITE_FONT_STYLE_NORMAL,
            DWRITE_FONT_STRETCH_NORMAL, 64, L"en-us", g_clockFormat.GetAddressOf()); if (FAILED(hr)) return hr;
    }
    if (!g_smallFormat) {
        hr = g_dwrite->CreateTextFormat(L"Consolas", nullptr, DWRITE_FONT_WEIGHT_NORMAL, DWRITE_FONT_STYLE_NORMAL,
            DWRITE_FONT_STRETCH_NORMAL, 18, L"en-us", g_smallFormat.GetAddressOf()); if (FAILED(hr)) return hr;
    }
    return S_OK;
}
static void SetBrushAlpha(ID2D1SolidColorBrush* b, float a) { if (b) { D2D1_COLOR_F c = b->GetColor(); c.a = a; b->SetColor(c); } }
static void DrawTextLine(WindowRender& r, const std::wstring& s, float x, float y, float w, float h, ID2D1SolidColorBrush* b, IDWriteTextFormat* fmt) {
    if (!s.empty()) r.target->DrawText(s.c_str(), (UINT32)s.size(), fmt, D2D1::RectF(x, y, x + w, y + h), b, D2D1_DRAW_TEXT_OPTIONS_CLIP);
}
static void DrawMiku(WindowRender& r, float sw, float sh, float fade) {
    if (!g_mikuBitmap || fade <= 0) return;
    float iw = g_mikuBitmap->GetSize().width, ih = g_mikuBitmap->GetSize().height;
    float scale = (std::min)(sw * .43f / iw, sh * .78f / ih), dw = iw * scale, dh = ih * scale;
    float margin = sw < 1000 ? 28.f : 52.f, left = sw - margin - dw, top = (sh - dh) * .5f;
    D2D1_RECT_F dest = D2D1::RectF(left, top, left + dw, top + dh);
    // The image already contains the feathered edge; draw without a shadow/glow layer.
    r.target->DrawBitmap(g_mikuBitmap.Get(), dest, fade, D2D1_BITMAP_INTERPOLATION_MODE_LINEAR, nullptr);
    double t = GetTickCount64() / 1000.0;
    for (const auto& p : g_particles) {
        float xn = p.x, yn = p.y;
        if (!p.onCharacter) {
            yn = (float)fmod((double)p.y + t * p.speed, 1.14);
            xn += .015f * sinf((float)t * .47f + p.phase) + .007f * sinf((float)t * .23f + p.phase * 1.4f);
            if (xn < -.2f) xn = 1.2f; if (xn > 1.2f) xn = -.2f;
        } else { xn += .0025f * sinf((float)t + p.phase); yn += .0025f * cosf((float)t * .8f + p.phase); }
        float x = left + xn * dw, y = top + yn * dh;
        float tw = .25f + .75f * (.5f + .5f * sinf((float)t * 1.6f + p.phase));
        float size = p.size * g_particleSizeScale * (.7f + tw * .5f);
        r.particleGlow->SetOpacity(fade * tw * .45f);
        r.target->FillEllipse(D2D1::Ellipse(D2D1::Point2F(x, y), size * 2.2f, size * 2.2f), r.particleGlow.Get());
        r.particle->SetOpacity(fade * tw * (p.onCharacter ? .48f : .62f));
        r.target->FillEllipse(D2D1::Ellipse(D2D1::Point2F(x, y), size * .5f, size * .5f), r.particle.Get());
    }
}
static void Paint(HWND hwnd) {
    WindowRender& r = (hwnd == g_primaryWindow) ? g_mainRender : g_secondaryRender;
    if (!r.target && FAILED(CreateRender(hwnd, r))) return;
    D2D1_SIZE_F sz = r.target->GetSize(); float w = sz.width, h = sz.height;
    r.target->BeginDraw(); r.target->Clear(D2D1::ColorF(0, 0, 0));
    if (hwnd == g_primaryWindow) {
        ULONGLONG elapsed = GetTickCount64() - g_started;
        float textFade = elapsed <= TEXT_DELAY_MS ? 0.0f : (float)(elapsed - TEXT_DELAY_MS) / (float)TEXT_FADE_MS;
        if (textFade > 1) textFade = 1; if (g_preview) textFade = 1;
        if (textFade > 0) {
            SetBrushAlpha(r.white.Get(), textFade); SetBrushAlpha(r.date.Get(), textFade); SetBrushAlpha(r.heading.Get(), textFade);
            SetBrushAlpha(r.cpu.Get(), textFade); SetBrushAlpha(r.cpuModel.Get(), textFade); SetBrushAlpha(r.memory.Get(), textFade);
            SetBrushAlpha(r.gpu.Get(), textFade); SetBrushAlpha(r.uptime.Get(), textFade);
            float margin = w < 1000 ? 28.f : 52.f, clockSize = w < 1000 ? 36.f : 64.f, smallSize = w < 1000 ? 12.f : 18.f;
            DrawTextLine(r, GetClockText(), margin, margin, w * .7f, clockSize + 10, r.white.Get(), g_clockFormat.Get());
            DrawTextLine(r, GetDateText(), margin, margin + clockSize + 12, w * .7f, smallSize + 8, r.date.Get(), g_smallFormat.Get());
            DrawTextLine(r, L"SYSTEM INFO:", margin, h - margin - smallSize * 6 - 15, w * .6f, smallSize + 6, r.heading.Get(), g_smallFormat.Get());
            DrawTextLine(r, FixedInfoLine(L"CPU", Two((int)(g_cpuPercent + .5)) + L"%"), margin, h - margin - smallSize * 5 - 12, w * .75f, smallSize + 6, r.cpu.Get(), g_smallFormat.Get());
            DrawTextLine(r, FixedInfoLine(L"CPU MODEL", GetCpuName()), margin, h - margin - smallSize * 4 - 9, w * .75f, smallSize + 6, r.cpuModel.Get(), g_smallFormat.Get());
            DrawTextLine(r, GetMemoryText(), margin, h - margin - smallSize * 3 - 6, w * .75f, smallSize + 6, r.memory.Get(), g_smallFormat.Get());
            DrawTextLine(r, GetGpuText(), margin, h - margin - smallSize * 2 - 3, w * .75f, smallSize + 6, r.gpu.Get(), g_smallFormat.Get());
            DrawTextLine(r, GetUptimeText(), margin, h - margin - smallSize, w * .75f, smallSize + 6, r.uptime.Get(), g_smallFormat.Get());
        }
        float mikuFade = 0;
        if (g_preview) mikuFade = 1;
        else if (elapsed > MIKU_DELAY_MS) { float x = (float)(elapsed - MIKU_DELAY_MS) / (float)MIKU_FADE_MS; if (x > 1) x = 1; mikuFade = x * x * (3 - 2 * x); }
        DrawMiku(r, w, h, mikuFade);
    }
    HRESULT hr = r.target->EndDraw(); if (hr == D2DERR_RECREATE_TARGET) { r.target.Reset(); if (hwnd == g_primaryWindow) { g_mikuBitmap.Reset(); g_glowBitmap.Reset(); } }
}
static BOOL CALLBACK CollectMonitors(HMONITOR mon, HDC, LPRECT, LPARAM) {
    MONITORINFO mi{}; mi.cbSize = sizeof(mi);
    if (GetMonitorInfoW(mon, &mi)) g_monitors.push_back({ mi.rcMonitor, (mi.dwFlags & MONITORINFOF_PRIMARY) != 0 });
    return TRUE;
}
static LRESULT CALLBACK WindowProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_CREATE: SetTimer(hwnd, TIMER_ID, ANIM_TIMER_MS, nullptr); return 0;
    case WM_TIMER: {
        if ((UINT_PTR)wp == TIMER_ID) {
            ULONGLONG e = GetTickCount64() - g_started;
            UINT wanted = (g_preview || (hwnd == g_primaryWindow && g_mikuBitmap && e >= MIKU_DELAY_MS)) ? ANIM_TIMER_MS : ((e >= TEXT_DELAY_MS + TEXT_FADE_MS) ? IDLE_TIMER_MS : ANIM_TIMER_MS);
            SetTimer(hwnd, TIMER_ID, wanted, nullptr); InvalidateRect(hwnd, nullptr, FALSE);
        } return 0;
    }
    case WM_SIZE: { WindowRender& r = hwnd == g_primaryWindow ? g_mainRender : g_secondaryRender; if (r.target) r.target->Resize(D2D1::SizeU(LOWORD(lp), HIWORD(lp))); return 0; }
    case WM_ERASEBKGND: return 1;
    case WM_PAINT: { PAINTSTRUCT ps; BeginPaint(hwnd, &ps); Paint(hwnd); EndPaint(hwnd, &ps); return 0; }
    case WM_KEYDOWN: case WM_LBUTTONDOWN: case WM_RBUTTONDOWN: case WM_MBUTTONDOWN: case WM_XBUTTONDOWN:
        if (!g_preview) PostQuitMessage(0); return 0;
    case WM_MOUSEMOVE:
        if (!g_preview) { POINT p{}; GetCursorPos(&p); if (!g_haveInitialMouse) { g_initialMouse = p; g_haveInitialMouse = true; } else if (abs(p.x - g_initialMouse.x) > 8 || abs(p.y - g_initialMouse.y) > 8) PostQuitMessage(0); } return 0;
    case WM_CLOSE: PostQuitMessage(0); return 0;
    case WM_DESTROY: KillTimer(hwnd, TIMER_ID); return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}
int WINAPI wWinMain(HINSTANCE inst, HINSTANCE, PWSTR, int) {
    int argc = 0; LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
    bool config = false, preview = false; HWND parent = nullptr;
    for (int i = 1; i < argc; ++i) {
        if (!_wcsicmp(argv[i], L"/c") || !_wcsicmp(argv[i], L"-c")) config = true;
        if (!_wcsicmp(argv[i], L"/p") || !_wcsicmp(argv[i], L"-p")) { preview = true; if (i + 1 < argc) parent = (HWND)(ULONG_PTR)_wcstoui64(argv[i + 1], nullptr, 10); }
    }
    if (argv) LocalFree(argv);
    LoadSettings();
    if (config) {
        std::wstring path = g_configPath;
        ShellExecuteW(nullptr, L"open", L"notepad.exe", (L"\"" + path + L"\"").c_str(), nullptr, SW_SHOWNORMAL);
        return 0;
    }
    HRESULT com = CoInitializeEx(nullptr, COINIT_APARTMENTTHREADED);
    HRESULT hrD2D = D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, IID_PPV_ARGS(g_d2d.GetAddressOf()));
    HRESULT hrDW = DWriteCreateFactory(DWRITE_FACTORY_TYPE_SHARED, __uuidof(IDWriteFactory), reinterpret_cast<IUnknown**>(g_dwrite.GetAddressOf()));
    HRESULT hrWIC = CoCreateInstance(CLSID_WICImagingFactory, nullptr, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(g_wic.GetAddressOf()));
    if (FAILED(hrD2D) || FAILED(hrDW) || FAILED(hrWIC)) {
        MessageBoxW(nullptr, L"Could not initialize Direct2D, DirectWrite, or Windows Imaging Component.", L"VOID", MB_ICONERROR);
        if (SUCCEEDED(com)) CoUninitialize(); return 1;
    }
    g_preview = preview; g_started = GetTickCount64(); UpdateCpu();
    const wchar_t* cls = L"VoidScreensaverWindow"; WNDCLASSW wc{}; wc.hInstance = inst; wc.lpfnWndProc = WindowProc; wc.lpszClassName = cls;
    wc.hCursor = LoadCursor(nullptr, IDC_ARROW); wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH);
    if (!RegisterClassW(&wc) && GetLastError() != ERROR_CLASS_ALREADY_EXISTS) { if (SUCCEEDED(com)) CoUninitialize(); return 1; }
    if (preview && parent) {
        RECT r{}; GetClientRect(parent, &r);
        g_primaryWindow = CreateWindowExW(0, cls, L"VOID", WS_CHILD | WS_VISIBLE, 0, 0, r.right, r.bottom, parent, nullptr, inst, nullptr);
        if (!g_primaryWindow) { if (SUCCEEDED(com)) CoUninitialize(); return 1; }
    } else {
        EnumDisplayMonitors(nullptr, nullptr, CollectMonitors, 0);
        if (g_monitors.empty()) { RECT r{ 0,0,GetSystemMetrics(SM_CXSCREEN),GetSystemMetrics(SM_CYSCREEN) }; g_monitors.push_back({ r, true }); }
        for (auto& m : g_monitors) if (m.primary) {
            g_primaryWindow = CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW, cls, L"VOID", WS_POPUP | WS_VISIBLE,
                m.rect.left, m.rect.top, m.rect.right - m.rect.left, m.rect.bottom - m.rect.top, nullptr, nullptr, inst, nullptr); break;
        }
        if (!g_primaryWindow) { if (SUCCEEDED(com)) CoUninitialize(); return 1; }
        for (auto& m : g_monitors) if (!m.primary) CreateWindowExW(WS_EX_TOPMOST | WS_EX_TOOLWINDOW, cls, L"VOID", WS_POPUP | WS_VISIBLE,
            m.rect.left, m.rect.top, m.rect.right - m.rect.left, m.rect.bottom - m.rect.top, nullptr, nullptr, inst, nullptr);
        while (ShowCursor(FALSE) >= 0) ++g_cursorHideCalls; ++g_cursorHideCalls;
        SetForegroundWindow(g_primaryWindow); SetWindowPos(g_primaryWindow, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_SHOWWINDOW);
    }
    if (SUCCEEDED(CreateRender(g_primaryWindow, g_mainRender))) LoadMiku();
    MSG msg{}; ULONGLONG lastCpu = 0;
    while (GetMessageW(&msg, nullptr, 0, 0) > 0) {
        ULONGLONG now = GetTickCount64(); if (now - lastCpu >= 1000) { UpdateCpu(); lastCpu = now; }
        TranslateMessage(&msg); DispatchMessageW(&msg);
    }
    if (!preview) for (int i = 0; i < g_cursorHideCalls; ++i) ShowCursor(TRUE);
    g_mainRender = WindowRender{}; g_secondaryRender = WindowRender{}; g_glowBitmap.Reset(); g_mikuBitmap.Reset();
    g_wic.Reset(); g_dwrite.Reset(); g_d2d.Reset(); if (SUCCEEDED(com)) CoUninitialize(); return (int)msg.wParam;
}
