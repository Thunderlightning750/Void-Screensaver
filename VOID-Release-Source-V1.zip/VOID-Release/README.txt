VOID — Direct2D Screensaver
===========================

BUILD
-----
For developers: open VoidScreensaver.vcxproj in Visual Studio, or run Build-Void.bat from a Visual Studio Developer Command Prompt. The project targets x64, C++17, and MSVC v145.

INSTALL
-------
1. Put your chosen image in assets\background.png (recommended) before installation. You can also put background.png beside Install.bat.
2. Run Build-Void.bat, then run Install.bat and approve the administrator prompt.
3. The installer creates Documents\VOID and copies your bundled image there as background.png, along with Void.ini. If elevation fails, right-click Install.bat and choose Run as administrator. The installer log is %TEMP%\VOID-Install.log.
4. Open Windows Screen Saver Settings and select VOID.

The installer copies the image on first install only; it will not overwrite a background.png or Void.ini you already customized in Documents\VOID. To change the installed image later, replace Documents\VOID\background.png yourself, or change Image= in Void.ini.

YOUR FILES
----------
After installation, your user-editable files are stored in your Windows Documents folder:
Documents\VOID\Void.ini
Documents\VOID\background.png

The program asks Windows for the actual Documents folder, so redirected/OneDrive Documents locations are supported. Run Void.scr /c to open the INI in Notepad.

SETTINGS
--------
[Appearance]
Image=background.png
PostBlur=true
ParticleColor=#00E5CC
ParticleSize=1.0
ParticleAmount=50

Image: A path to the image. Relative paths are resolved relative to Documents\VOID. Absolute paths are supported, for example C:\Users\You\Pictures\character.png.
PostBlur: true feathers the image's edges into transparency; false draws the original image without that processing.
ParticleColor: RGB hex color in #RRGGBB format. Example: #00E5CC (teal), #FF66CC (pink), #FFFFFF (white).
ParticleSize: 0.1 to 5.0 multiplier.
ParticleAmount: 0 to 200 particles.

The source image is never overwritten. The feathered copy is cached separately in Documents\VOID\background_void.png. Reinstalling VOID does not overwrite an existing Void.ini or background.png.

CHANGING YOUR IMAGE OR SETTINGS
-------------------------------
No reinstall is needed. Replace Documents\VOID\background.png, or edit the Image= line in Void.ini. Open Void.ini in Notepad to change particle and blur settings. Exit and reopen the screensaver to apply changes.

NOTES
-----
This package does not include a character image. Add an image you have permission to use as assets\background.png before installing (or place background.png beside Install.bat). The installer copies it to Documents\VOID\background.png if no user image exists there yet. If no image is present at the configured path, the clock/system text still runs, but the character and its particles will not appear.
