@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title VOID Screensaver Builder

where msbuild >nul 2>nul
if errorlevel 1 (
  echo ERROR: MSBuild was not found.
  echo Open the Visual Studio Developer Command Prompt, or install Visual Studio with Desktop development with C++.
  pause
  exit /b 1
)

echo Building VOID x64 Release...
msbuild "VoidScreensaver.vcxproj" /p:Configuration=Release /p:Platform=x64 /m
if errorlevel 1 (
  echo.
  echo BUILD FAILED. See the compiler errors above.
  pause
  exit /b 1
)

if not exist "build\Release\Void.exe" (
  echo ERROR: Build succeeded but build\Release\Void.exe was not found.
  pause
  exit /b 1
)
copy /Y "build\Release\Void.exe" "Void.scr" >nul
if errorlevel 1 (
  echo ERROR: Could not create Void.scr.
  pause
  exit /b 1
)
if not exist "assets" mkdir "assets"
echo.
echo SUCCESS: %~dp0Void.scr
 echo The screensaver is ready. Install it with Install.bat (administrator permission required).
pause
