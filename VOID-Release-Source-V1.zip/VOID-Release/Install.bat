@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title VOID Screensaver Installer

rem Start logging immediately, before checking files or requesting elevation.
set "LOG=%TEMP%\VOID-Install.log"
echo ==== VOID installer started %DATE% %TIME% ==== > "%LOG%"
echo Script: %~f0 >> "%LOG%"
echo Source folder: %~dp0 >> "%LOG%"

set "DEST=%WINDIR%\System32"
set "SOURCE_IMAGE="

if not exist "%~dp0Void.scr" (
  echo ERROR: Void.scr was not found beside Install.bat.
  echo Missing file: "%~dp0Void.scr" >> "%LOG%"
  echo Run Build-Void.bat first, then try again.
  echo Log: "%LOG%"
  pause
  exit /b 1
)

if exist "%~dp0assets\background.png" set "SOURCE_IMAGE=%~dp0assets\background.png"
if not defined SOURCE_IMAGE if exist "%~dp0background.png" set "SOURCE_IMAGE=%~dp0background.png"
if defined SOURCE_IMAGE echo Source image: %SOURCE_IMAGE%>> "%LOG%"

rem Detect administrator rights. If needed, relaunch this batch through elevated cmd.exe.
fltmc >nul 2>&1
if errorlevel 1 (
  echo Requesting administrator permission...
  echo Requesting elevation. >> "%LOG%"
  set "VOID_INSTALL_SCRIPT=%~f0"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$script = $env:VOID_INSTALL_SCRIPT; $cmd = $env:ComSpec; $args = '/d /c call ""' + $script + '""'; Start-Process -FilePath $cmd -ArgumentList $args -Verb RunAs -Wait"
  set "ELEVATE_RESULT=%ERRORLEVEL%"
  echo Elevation launcher returned: %ELEVATE_RESULT% >> "%LOG%"
  if not "%ELEVATE_RESULT%"=="0" (
    echo ERROR: Windows could not launch the elevated installer.
    echo Try right-clicking Install.bat and selecting Run as administrator.
    echo Log: "%LOG%"
    pause
    exit /b 1
  )
  exit /b 0
)

echo Running with administrator rights. >> "%LOG%"
echo Installing VOID to "%DEST%"...
echo Destination: %DEST% >> "%LOG%"

copy /Y "%~dp0Void.scr" "%DEST%\Void.scr" >> "%LOG%" 2>&1
if errorlevel 1 goto :fail
echo Copied Void.scr successfully. >> "%LOG%"

rem Resolve the real Documents folder (including OneDrive or redirected Documents).
for /f "usebackq delims=" %%D in (`powershell -NoProfile -Command "[Environment]::GetFolderPath('MyDocuments')"`) do set "DOCS=%%D"
if not defined DOCS set "DOCS=%USERPROFILE%\Documents"
set "USERVOID=%DOCS%\VOID"
echo Documents: "%DOCS%" >> "%LOG%"
echo User settings folder: "%USERVOID%" >> "%LOG%"

if not exist "%USERVOID%" mkdir "%USERVOID%" >> "%LOG%" 2>&1
if not exist "%USERVOID%" goto :fail
echo Documents\VOID folder is ready. >> "%LOG%"

if not exist "%USERVOID%\Void.ini" (
  if exist "%~dp0Void.ini" (
    copy /Y "%~dp0Void.ini" "%USERVOID%\Void.ini" >> "%LOG%" 2>&1
    if errorlevel 1 goto :fail
  ) else (
    echo WARNING: Void.ini is missing from the source folder. >> "%LOG%"
  )
)

if not exist "%USERVOID%\background.png" (
  if defined SOURCE_IMAGE (
    copy /Y "%SOURCE_IMAGE%" "%USERVOID%\background.png" >> "%LOG%" 2>&1
    if errorlevel 1 goto :fail
  ) else (
    echo WARNING: No background.png found in assets or beside Install.bat. >> "%LOG%"
    echo Put your image in assets\background.png before installing.
  )
)

rem Ask Windows to register/select the screensaver. Log any output for troubleshooting.
echo Registering screensaver. >> "%LOG%"
rundll32.exe desk.cpl,InstallScreenSaver "%DEST%\Void.scr" >> "%LOG%" 2>&1

echo Installation steps completed. >> "%LOG%"
echo.
echo VOID installed.
echo Settings: "%USERVOID%\Void.ini"
echo Image:    "%USERVOID%\background.png"
echo Log:      "%LOG%"
echo.
echo Existing settings and images are preserved. To change them, edit files in Documents\VOID.
pause
exit /b 0

:fail
echo ERROR: Installation failed. >> "%LOG%"
echo ERROR: Installation failed. Check the log below:
echo "%LOG%"
type "%LOG%"
pause
exit /b 1
